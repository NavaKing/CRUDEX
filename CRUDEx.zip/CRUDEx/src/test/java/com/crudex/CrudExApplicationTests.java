package com.crudex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudExApplicationTests {

	@Test
	void contextLoads() {
	}

}
