package com.crudex.post;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class PostController {
	
	@Autowired
	PostRepository dao;


	@GetMapping("/post")
	public List<Post> getPosts() {
	    List<Post> foundPosts = dao.findAll();
	    return foundPosts;
	}
	
	@GetMapping("/post/{id}")
    public ResponseEntity<Post> getUser(@PathVariable(value="id") Integer id) {
        Post foundPosts = dao.findById(id).orElse(null);

        if(foundPosts == null) {
            return ResponseEntity.notFound().header("Post","Nothing found with that id").build();
        }
        return ResponseEntity.ok(foundPosts);
    }
	
	@PostMapping("/post")
	public ResponseEntity<Post> postPost(@RequestBody Post post){
		Post createdPost = dao.save(post);
		
		return ResponseEntity.ok(createdPost);
	}
	
	@DeleteMapping("/post/{id}")
	public ResponseEntity<Post> deleteUser(@PathVariable(value="id") Integer id) {
		Post foundPosts = dao.findById(id).orElse(null);
		
		if(foundPosts == null) {
			return ResponseEntity.notFound().header("Post", "Nothing found with that id").build();
		} else {
			
			dao.delete(foundPosts);
		}
		
		return ResponseEntity.ok().build();
	}


}