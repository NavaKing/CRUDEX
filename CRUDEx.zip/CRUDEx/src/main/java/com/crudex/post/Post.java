package com.crudex.post;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="post")

//ID: int
//authorID: String
//message: String
//timeStamp: DateTime


public class Post {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
		private int ID;
		private String authorID;
		private String message;
		private String timeStamp;
		
		
		
		public int getID() {
			return ID;
		}
		public void setID(int ID) {
			this.ID= ID;
		}
		
		
		
		public String getAuthorID() {
				return authorID;
			}
		
		public void setAuthorID (String authorID) {
			this.authorID = authorID;
		}
		
		
		
		
		public String getMessage() {
			
			return message;
		}
		
		public void setMessage(String message) {
			this.message = message;
		}
		
		
		
		
		public String getTimeStamp() {
			
			return timeStamp;
		}
		public void setTimeStamp(String timeStamp) {
			this.timeStamp = timeStamp;
		}
		
		
	

}
	
