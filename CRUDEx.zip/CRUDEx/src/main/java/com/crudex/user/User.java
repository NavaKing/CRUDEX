package com.crudex.user;

import javax.persistence.*;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@Table(name="user")

public class User {

	//ID: int
	//firstName: String
	//lastName: String
	//username: String
	//password: String

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int ID;
		private String firstName;
		private String lastName;
		private String userName;
		private String password;
		
		
		public int getID() {
			return ID;
		}
		public void setID(int ID) {
			this.ID= ID;
		}
		
		
		
		public String getFirstName() {
				return firstName;
			}
		
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		
		
		
		
		public String getLastName() {
			
			return lastName;
		}
		
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		
		
		
		
		public String getUserName() {
			
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		
		
		
		
		public String getPassword() {
			
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
}
